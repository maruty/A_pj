<?php
/**
 * @author NetBusinessAgent
 * @version 1.0.0
 */
get_template_part( 'template/template', 'news' );